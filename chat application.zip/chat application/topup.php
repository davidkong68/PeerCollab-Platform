<?php
// Database Connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "phpchatapp_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

session_start();

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $amount = filter_var($_POST['amount'], FILTER_VALIDATE_FLOAT);
    $payment_method = filter_input(INPUT_POST, 'payment_method', FILTER_SANITIZE_STRING);
    
    if ($amount && $payment_method) {
        // Generate reference number
        $reference_number = 'TOP' . time() . rand(1000, 9999);
        
        // Insert transaction record
        $stmt = $conn->prepare("INSERT INTO transactions (user_id, amount, type, payment_method, reference_number) VALUES (?, ?, 'deposit', ?, ?)");
        $stmt->bind_param("idss", $user_id, $amount, $payment_method, $reference_number);
        
        if ($stmt->execute()) {
            // Update user balance
            $update_balance = $conn->prepare("UPDATE users SET balance = balance + ? WHERE user_id = ?");
            $update_balance->bind_param("di", $amount, $user_id);
            $update_balance->execute();
            
            $success_message = "Top-up successful! Reference number: " . $reference_number;
        } else {
            $error_message = "Transaction failed. Please try again.";
        }
    } else {
        $error_message = "Invalid amount or payment method.";
    }
}

// Fetch user's current balance
$balance_query = $conn->prepare("SELECT balance FROM users WHERE user_id = ?");
$balance_query->bind_param("i", $user_id);
$balance_query->execute();
$balance_result = $balance_query->get_result();
$current_balance = $balance_result->fetch_assoc()['balance'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Top Up Money - Junior & Senior</title>
    <meta http-equiv="Content-Security-Policy" content="default-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://unpkg.com; font-src 'self' https://fonts.gstatic.com; script-src 'self' 'unsafe-inline' https://unpkg.com; connect-src 'self';">
  
    <link rel="stylesheet" href="bootstrap-icons-1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="topup.css">
    
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo-details">
            <i class='bx bxl-c-plus-plus icon'></i>
            <div class="logo_name">PeerCollab</div>
            <i class="bi bi-list" id="btn"></i>
        </div>
        <ul class="nav-list">
            <li>
                <a href="index1.php">
                    <i class="bi bi-chat-dots-fill"></i>
                    <span class="links_name">Chat</span>
                </a>
                <span class="tooltip">Chat</span>
            </li>
            <li>
                <a href="booking.php">
                    <i class="bi bi-calendar-check-fill"></i>
                    <span class="links_name">My booking</span>
                </a>
                <span class="tooltip">My booking</span>
            </li>
            <li>
                <a href="topup.php">
                    <i class="bi bi-bank"></i>
                    <span class="links_name">Top up money</span>
                </a>
                <span class="tooltip">Top up money</span>
                
            </li>
            <li>
                <a href="setting.php">
                    <i class="bi bi-gear"></i>
                    <span class="links_name">Setting</span>
                </a>
                <span class="tooltip">Setting</span>
            </li>
            <li class="profile">
                <div class="profile-details">
                    <img src="images/handsome_guy.jpg" alt="profileImg">
                    <div class="name_job">
                        <div class="name">David</div>
                    </div>
                </div>
                <a href="homepage.html">
                <i class='bi bi-box-arrow-left' id="log_out"></i>
                </a>
            </li>
        </ul>
    </div>

    <section class="home-section">
     
        
        <div class="top-up-container">
            <?php if (isset($success_message)): ?>
                <div class="success-message"><?php echo $success_message; ?></div>
            <?php endif; ?>
            
            <?php if (isset($error_message)): ?>
                <div class="error-message"><?php echo $error_message; ?></div>
            <?php endif; ?>

            <div class="balance-card">
                <h3>Current Balance</h3>
                <div class="balance-amount">$<?php echo number_format($current_balance, 2); ?></div>
            </div>

            <div class="top-up-form">
                <h3>Top Up Your Account</h3>
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="amount">Amount (USD)</label>
                        <input type="number" id="amount" name="amount" min="1" step="0.01" required 
                               class="form-control">
                    </div>

                    <div class="form-group">
                        <label>Select Payment Method</label>
                        <div class="payment-methods">
                            <div class="payment-method" data-method="credit_card">
                                <i class="bi bi-credit-card"></i>
                                <div>Credit Card</div>
                            </div>
                            <div class="payment-method" data-method="bank_transfer">
                                <i class="bi bi-bank"></i>
                                <div>Bank Transfer</div>
                            </div>
                            <div class="payment-method" data-method="e_wallet">
                                <i class="bi bi-wallet2"></i>
                                <div>E-Wallet</div>
                            </div>
                        </div>
                        <input type="hidden" name="payment_method" id="payment_method" required>
                    </div>

                    <button type="submit" class="confirm-btn" style="width: 100%; margin-top: 20px;">
                        Confirm Top Up
                    </button>
                </form>
            </div>
        </div>
    </section>

    <script src="index1.js"></script>

    <script>
        // Payment method selection
        document.querySelectorAll('.payment-method').forEach(method => {
            method.addEventListener('click', function() {
                // Remove selected class from all methods
                document.querySelectorAll('.payment-method').forEach(m => {
                    m.classList.remove('selected');
                });
                
                // Add selected class to clicked method
                this.classList.add('selected');
                
                // Update hidden input
                document.getElementById('payment_method').value = this.dataset.method;
            });
        });
    </script>
</body>
</html>

<?php
$conn->close();
?>