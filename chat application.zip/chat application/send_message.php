<?php
// Disable error reporting and set strict JSON headers
error_reporting(0);
ini_set('display_errors', 0);
header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "phpchatapp_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error', 
        'message' => 'Database connection failed'
    ]);
    exit;
}

// Start session
session_start();

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve message and receiver ID
    $message = isset($_POST['message']) ? trim($_POST['message']) : '';
    $receiver_id = isset($_POST['receiver_id']) ? intval($_POST['receiver_id']) : 0;
    
    // Get the logged-in user ID from session
    $sender_id = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : 1;

    // Validate inputs
    if (empty($message)) {
        http_response_code(400);
        echo json_encode([
            'status' => 'error', 
            'message' => 'Message cannot be empty.'
        ]);
        exit;
    }

    if ($receiver_id <= 0) {
        http_response_code(400);
        echo json_encode([
            'status' => 'error', 
            'message' => 'Invalid receiver ID.'
        ]);
        exit;
    }

    // Prepare and execute the SQL statement

    
    $stmt = $conn->prepare("INSERT INTO messages (sender_id, receiver_id, message, timestamp) VALUES (?, ?, ?, NOW())");
    $stmt->bind_param("iis", $sender_id, $receiver_id, $message);

    try {
        if ($stmt->execute()) {
            echo json_encode([
                'status' => 'success', 
                'message' => 'Message sent successfully.'
            ]);
        } else {
            http_response_code(500);
            echo json_encode([
                'status' => 'error', 
                'message' => 'Failed to send the message.'
            ]);
        }
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'status' => 'error', 
            'message' => 'An unexpected error occurred.'
        ]);
    } finally {
        $stmt->close();
        $conn->close();
    }
} else {
    http_response_code(405);
    echo json_encode([
        'status' => 'error', 
        'message' => 'Method Not Allowed'
    ]);
}
exit;
