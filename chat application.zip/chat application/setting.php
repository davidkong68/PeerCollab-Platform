<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "phpchatapp_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION['user_id'];

// Fetch user's information
$user_query = $conn->prepare("SELECT name, profile_image, email FROM users WHERE user_id = ?");
if (!$user_query) {
    die("Error preparing query: " . $conn->error);
}

$user_query = $conn->prepare("SELECT name, profile_image, email FROM users WHERE user_id = ?");
$user_query->bind_param("i", $user_id);
$user_query->execute();
$user_result = $user_query->get_result();
$user_data = $user_result->fetch_assoc();
$user_query->bind_param("i", $user_id);
$user_query->execute();
$user_result = $user_query->get_result();
$user_data = $user_result->fetch_assoc();

//this line to initialize session profile_image
$_SESSION['profile_image'] = $user_data['profile_image'];

// Fetch user's courses
$course_query = $conn->prepare("SELECT id, course_name FROM course WHERE user_id = ?");
if (!$course_query) {
    die("Error preparing query: " . $conn->error);
}
$course_query->bind_param("i", $user_id);
$course_query->execute();
$courses = $course_query->get_result();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - Junior & Senior</title>
    <link rel="stylesheet" href="bootstrap-icons-1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="index1.css">
    <link rel="stylesheet" href="setting.css">
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo-details">
            <i class='bx bxl-c-plus-plus icon'></i>
            <div class="logo_name">PeerCollab</div>
            <i class="bi bi-list" id="btn"></i>
        </div>
        <ul class="nav-list">
            <li>
                <a href="index1.php">
                    <i class="bi bi-chat-dots-fill"></i>
                    <span class="links_name">Chat</span>
                </a>
                <span class="tooltip">Chat</span>
            </li>
            <li>
                <a href="booking.php">
                    <i class="bi bi-calendar-check-fill"></i>
                    <span class="links_name">My booking</span>
                </a>
                <span class="tooltip">My booking</span>
            </li>
            <li>
                <a href="topup.php">
                    <i class="bi bi-bank"></i>
                    <span class="links_name">Top up money</span>
                </a>
                <span class="tooltip">Top up money</span>
            </li>
            <li class="active">
                <a href="setting.php">
                    <i class="bi bi-gear"></i>
                    <span class="links_name">Setting</span>
                </a>
                <span class="tooltip">Setting</span>
            </li>
            <li class="profile">
            <div class="profile-details">
                <img src="<?php 
                    if (!empty($_SESSION['profile_image'])) {
                        echo 'uploads/' . htmlspecialchars($_SESSION['profile_image']);
                    } else {
                        echo 'images/default-avatar.jpg';
                    }
                ?>" alt="Profile">
                <div class="name_job">
                    <div class="name"><?php echo htmlspecialchars($user_data['name']); ?></div>
                    
                </div>
            </div>
                <a href="homepage.html">
                <i class='bi bi-box-arrow-left' id="log_out" ></i>
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="settings-content">
        <div class="settings-container">
            <div id="alert" class="alert"></div>

            <!-- Profile Information Section -->
            <div class="settings-section">
                <h2 class="section-title">Profile Information</h2>
                <div class="profile-info-section">
                    <form id="profileInfoForm">
                        <div class="profile-info-group">
                            <label for="userName">Name</label>
                            <input 
                                type="text" 
                                id="userName" 
                                name="name" 
                                value="<?php echo htmlspecialchars($user_data['name']); ?>"
                                required
                            >
                        </div>
                        <div class="profile-info-group">
                            <label for="userEmail">Email (Read Only)</label>
                            <input 
                                type="email" 
                                id="userEmail" 
                                value="<?php echo htmlspecialchars($user_data['email']); ?>"
                                readonly
                                disabled
                            >
                        </div>
                        <div class="profile-info-footer">
                            <button type="submit" class="save-btn" id="saveProfileBtn">
                                <i class="bi bi-check2"></i> Save Changes
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Profile Photo Section -->
            <div class="settings-section profile-section">
                    <h2 class="section-title">Profile Photo</h2>
                    <img src="<?php 
                        if (!empty($_SESSION['profile_image'])) {
                            echo 'uploads/' . htmlspecialchars($_SESSION['profile_image']);
                        } else {
                            echo 'images/default-avatar.jpg';
                        }
                    ?>" 
                    alt="Profile Photo" 
                    class="profile-image" 
                    id="currentPhoto">
            <div class="upload-controls">
                <form id="uploadPhotoForm" enctype="multipart/form-data">
                    <input type="file" id="photoInput" name="photo" accept="image/*" style="display: none;">
                    <button type="button" class="upload-btn" onclick="document.getElementById('photoInput').click()">
                        <i class="bi bi-camera"></i> Change Photo
                    </button>
                </form>
            </div>
        </div>

            <!-- Courses Section -->
            <div class="settings-section">
                <h2 class="section-title">My Courses</h2>
                <div class="course-list">
                    <?php while ($course = $courses->fetch_assoc()): ?>
                        <div class="course-item" id="course-<?php echo $course['id']; ?>">
                            <span class="course-name"><?php echo htmlspecialchars($course['course_name']); ?></span>
                            <button class="delete-btn" onclick="deleteCourse(<?php echo $course['id']; ?>)">
                                <i class="bi bi-trash"></i>
                            </button>
                        </div>
                    <?php endwhile; ?>
                </div>
                <form id="addCourseForm" class="add-course-form">
                    <input type="text" id="newCourseName" placeholder="Enter course name" required>
                    <button type="submit">
                        <i class="bi bi-plus"></i> Add Course
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script src="setting.js"></script>
</body>
</html>

<?php $conn->close(); ?>