<?php
session_start();
require_once 'Database.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not logged in']);
    exit;
}

// Check if file was uploaded
if (!isset($_FILES['photo']) || $_FILES['photo']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['status' => 'error', 'message' => 'No file uploaded or upload error occurred']);
    exit;
}

$file = $_FILES['photo'];
$allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
$max_size = 5 * 1024 * 1024; // 5MB

// Validate file type
if (!in_array($file['type'], $allowed_types)) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid file type. Please use JPG, PNG, or GIF']);
    exit;
}

// Validate file size
if ($file['size'] > $max_size) {
    echo json_encode(['status' => 'error', 'message' => 'File too large. Maximum size is 5MB']);
    exit;
}

// Create uploads directory if it doesn't exist
$upload_dir = 'uploads/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}

// Generate unique filename
$filename = uniqid() . '_' . basename($file['name']);
$filepath = $upload_dir . $filename;

// Move uploaded file
if (move_uploaded_file($file['tmp_name'], $filepath)) {
    try {
        $db = Database::getInstance();
        $pdo = $db->getConnection();
        
        // Delete old profile image if exists
        $stmt = $pdo->prepare("SELECT profile_image FROM users WHERE user_id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $old_image = $stmt->fetchColumn();
        
        if ($old_image && file_exists($upload_dir . $old_image)) {
            unlink($upload_dir . $old_image);
        }
        
        // Update profile_image in database
        $stmt = $pdo->prepare("UPDATE users SET profile_image = ? WHERE user_id = ?");
        $result = $stmt->execute([$filename, $_SESSION['user_id']]);
        
        if ($result) {
            $_SESSION['profile_image'] = $filename;  // Add this line to store in session
            echo json_encode([
                'status' => 'success',
                'message' => 'Photo uploaded successfully',
                'photo_url' => $filepath
            ]);
        } else {
            unlink($filepath);
            echo json_encode(['status' => 'error', 'message' => 'Failed to update database']);
        }
        
    } catch (PDOException $e) {
        unlink($filepath);
        echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Failed to move uploaded file']);
}
?>