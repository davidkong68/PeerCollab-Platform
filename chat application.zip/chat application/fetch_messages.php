<?php
include 'db_connect.php';

$course_id = $_GET['course_id'];

$sql = "SELECT u.name, m.message, m.timestamp 
        FROM messages m 
        JOIN users u ON m.sender_id = u.user_id 
        WHERE m.course_id = ? 
        ORDER BY m.timestamp ASC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $course_id);
$stmt->execute();
$result = $stmt->get_result();

$messages = [];
while ($row = $result->fetch_assoc()) {
    $messages[] = $row;
}

echo json_encode($messages);
?>
