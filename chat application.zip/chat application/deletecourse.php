<?php
session_start();
header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not logged in']);
    exit;
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "phpchatapp_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Connection failed']);
    exit;
}

// Get the course ID from POST data
$json = file_get_contents('php://input');
$data = json_decode($json, true);
$courseId = isset($data['course_id']) ? (int)$data['course_id'] : 0;
$userId = $_SESSION['user_id'];

if ($courseId <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid course ID']);
    exit;
}

// Prepare and execute delete query
$stmt = $conn->prepare("DELETE FROM course WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $courseId, $userId);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        echo json_encode(['status' => 'success', 'message' => 'Course deleted successfully']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Course not found or unauthorized']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Failed to delete course']);
}

$stmt->close();
$conn->close();
?>