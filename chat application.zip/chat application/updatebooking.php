<?php
// updatebooking.php
session_start();
header('Content-Type: application/json');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "phpchatapp_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(['status' => 'error', 'message' => 'Connection failed']));
}

// Get JSON POST data
$data = json_decode(file_get_contents('php://input'), true);
$booking_id = $data['booking_id'];
$new_status = $data['status'];
$user_id = $_SESSION['user_id'];

// Start transaction
$conn->begin_transaction();

try {
    // Get booking details with both users' balances
    $check_query = "SELECT 
                        b.*,
                        u1.balance as booker_balance,
                        u2.balance as booked_balance,
                        u1.user_id as booker_id,
                        u2.user_id as booked_id
                    FROM bookings b 
                    JOIN users u1 ON b.booker_id = u1.user_id 
                    JOIN users u2 ON b.booked_id = u2.user_id 
                    WHERE b.booking_id = ? AND b.booked_id = ? AND b.status = 'pending'";
    
    $stmt = $conn->prepare($check_query);
    $stmt->bind_param("ii", $booking_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        throw new Exception("Unauthorized to update this booking or booking is not pending");
    }
    
    $booking = $result->fetch_assoc();
    
    if ($new_status === 'confirmed') {
        // Transfer money to the booked person (senior)
        $transfer_money = $conn->prepare("UPDATE users SET balance = balance + ? WHERE user_id = ?");
        $transfer_money->bind_param("di", $booking['amount'], $booking['booked_id']);
        if (!$transfer_money->execute()) {
            throw new Exception("Failed to transfer money to senior");
        }
    } 
    elseif ($new_status === 'cancelled') {
        // Return money to booker (junior)
        $return_money = $conn->prepare("UPDATE users SET balance = balance + ? WHERE user_id = ?");
        $return_money->bind_param("di", $booking['amount'], $booking['booker_id']);
        if (!$return_money->execute()) {
            throw new Exception("Failed to return money to booker");
        }
    } 
    else {
        throw new Exception("Invalid status update requested");
    }
    
    // Update booking status
    $update_booking = $conn->prepare("UPDATE bookings SET status = ? WHERE booking_id = ?");
    $update_booking->bind_param("si", $new_status, $booking_id);
    if (!$update_booking->execute()) {
        throw new Exception("Failed to update booking status");
    }
    
    // Get updated balances for confirmation
    $balance_query = $conn->prepare("SELECT user_id, balance FROM users WHERE user_id IN (?, ?)");
    $balance_query->bind_param("ii", $booking['booker_id'], $booking['booked_id']);
    $balance_query->execute();
    $balance_result = $balance_query->get_result();
    $updated_balances = [];
    while ($row = $balance_result->fetch_assoc()) {
        $updated_balances[$row['user_id']] = $row['balance'];
    }
    
    // Commit transaction
    $conn->commit();
    
    $message = $new_status === 'confirmed' ? 
        'Booking confirmed and payment transferred' : 
        'Booking cancelled and payment returned';
    
    echo json_encode([
        'status' => 'success',
        'message' => $message,
        'booking_status' => $new_status,
        'updated_balances' => $updated_balances
    ]);
    
} catch (Exception $e) {
    // Rollback transaction on error
    $conn->rollback();
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}

$conn->close();
?>