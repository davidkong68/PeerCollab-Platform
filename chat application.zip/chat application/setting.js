// Sidebar toggle functionality
document.addEventListener('DOMContentLoaded', function() {
    let sidebar = document.querySelector(".sidebar");
    let closeBtn = document.querySelector("#btn");
    let settingsContent = document.querySelector(".settings-content");

    closeBtn.addEventListener("click", () => {
        sidebar.classList.toggle("open");
        menuBtnChange();
        // Adjust main content margin
        if(sidebar.classList.contains("open")) {
            settingsContent.style.marginLeft = "250px";
        } else {
            settingsContent.style.marginLeft = "78px";
        }
    });

    function menuBtnChange() {
        if(sidebar.classList.contains("open")) {
            closeBtn.classList.replace("bi-list", "bi-x-lg");
        } else {
            closeBtn.classList.replace("bi-x-lg", "bi-list");
        }
    }
});

// Alert function to show success/error messages
function showAlert(message, type) {
    const alert = document.getElementById('alert');
    alert.textContent = message;
    alert.className = `alert alert-${type}`;
    alert.style.display = 'block';
    setTimeout(() => {
        alert.style.display = 'none';
    }, 3000);
}

// Handle profile information updates
document.getElementById('profileInfoForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const nameInput = document.getElementById('userName');
    const saveBtn = document.getElementById('saveProfileBtn');
    const name = nameInput.value.trim();
    
    if (!name) {
        showAlert('Please enter your name', 'error');
        return;
    }
    
    // Disable form while processing
    saveBtn.disabled = true;
    nameInput.disabled = true;
    
    // Show loading state
    saveBtn.innerHTML = '<i class="bi bi-hourglass"></i> Saving...';

    fetch('updatename.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            name: name
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            // Update UI
            document.querySelector('.profile-details .name').textContent = name;
            showAlert('Profile updated successfully', 'success');
        } else {
            showAlert(data.message || 'Error updating profile', 'error');
            nameInput.value = nameInput.defaultValue;
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showAlert('Error updating profile', 'error');
        nameInput.value = nameInput.defaultValue;
    })
    .finally(() => {
        // Re-enable form
        saveBtn.disabled = false;
        nameInput.disabled = false;
        saveBtn.innerHTML = '<i class="bi bi-check2"></i> Save Changes';
    });
});

document.getElementById('photoInput').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (!file) {
        return;
    }

    // Create FormData object
    const formData = new FormData();
    formData.append('photo', file);

    // Show loading state
    const uploadBtn = document.querySelector('.upload-btn');
    uploadBtn.innerHTML = '<i class="bi bi-hourglass"></i> Uploading...';
    uploadBtn.disabled = true;

    fetch('uploadphoto.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            // Update both the main profile photo and sidebar photo
            const newPhotoUrl = data.photo_url;
            
            // Update profile photo in settings
            const currentPhoto = document.getElementById('currentPhoto');
            if (currentPhoto) {
                currentPhoto.src = newPhotoUrl;
            }
            
            // Update sidebar profile photo
            const sidebarPhoto = document.querySelector('.profile-details img');
            if (sidebarPhoto) {
                sidebarPhoto.src = newPhotoUrl;
            }
            
            showAlert('Photo uploaded successfully', 'success');
            
            // Force page reload to ensure session is updated
            setTimeout(() => {
                window.location.reload();
            }, 1000);
        } else {
            showAlert(data.message || 'Error uploading photo', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showAlert('Error uploading photo', 'error');
    })
    .finally(() => {
        // Reset upload button
        uploadBtn.innerHTML = '<i class="bi bi-camera"></i> Change Photo';
        uploadBtn.disabled = false;
    });
});



// Handle course deletion
function deleteCourse(courseId) {
    if (!confirm('Are you sure you want to delete this course?')) {
        return;
    }

    const courseElement = document.getElementById(`course-${courseId}`);
    
    fetch('deletecourse.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ course_id: courseId })
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            courseElement.remove();
            showAlert('Course deleted successfully', 'success');
        } else {
            throw new Error(data.message || 'Error deleting course');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showAlert(error.message || 'Error deleting course', 'error');
    });
}


// Handle adding new course
document.getElementById('addCourseForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const courseInput = document.getElementById('newCourseName');
    const submitButton = this.querySelector('button[type="submit"]');
    const courseName = courseInput.value.trim();

    if (!courseName) {
        showAlert('Please enter a course name', 'error');
        return;
    }

    // Disable form while processing
    submitButton.disabled = true;
    courseInput.disabled = true;

    const requestData = { course_name: courseName };
    console.log('Sending data:', requestData);

    fetch('addcourse.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestData)
    })
    .then(response => {
        console.log('Raw response:', response);
        return response.text();  // Change to text() to see raw response
    })
    .then(rawText => {
        console.log('Raw response text:', rawText);
        const data = JSON.parse(rawText);
        console.log('Parsed response:', data);
        
        if (data.status === 'success') {
            showAlert('Course added successfully', 'success');
            courseInput.value = '';
            window.location.reload();  // Immediate reload on success
        } else {
            throw new Error(data.message || 'Error adding course');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showAlert(error.message || 'Error adding course', 'error');
    })
    .finally(() => {
        submitButton.disabled = false;
        courseInput.disabled = false;
    });
});

fetch('addcourse.php', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json'
    },
    body: JSON.stringify({
        course_name: "Test Course"
    })
})
.then(response => response.json())
.then(data => console.log(data))
.catch(error => console.error('Error:', error));


// Real-time validation for name input
document.getElementById('userName').addEventListener('input', function(e) {
    const saveBtn = document.getElementById('saveProfileBtn');
    const name = this.value.trim();
    
    if (name.length < 2 || name.length > 50) {
        saveBtn.disabled = true;
        if (name.length > 0) {
            showAlert('Name must be between 2 and 50 characters', 'error');
        }
    } else {
        saveBtn.disabled = false;
        // Clear any error messages
        const alert = document.getElementById('alert');
        if (alert.style.display === 'block') {
            alert.style.display = 'none';
        }
    }
});

// Logout functionality
document.getElementById('log_out').addEventListener('click', function() {
    window.location.href = 'logout.php';
});