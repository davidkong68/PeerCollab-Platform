<?php  // need to change this code to below code but login and signup page will not use pdo
class Database {
    private static $instance = null; // Singleton instance
    private $pdo; // PDO instance

    // Database credentials
    private $host = 'localhost';
    private $dbname = 'phpchatapp_db';
    private $username = 'root';
    private $password = '';

    // Private constructor to prevent direct instantiation
    private function __construct() {
        try {
            $this->pdo = new PDO("mysql:host={$this->host};dbname={$this->dbname};charset=utf8", $this->username, $this->password);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die('Database connection failed: ' . $e->getMessage());
        }
    }

    // Method to get the singleton instance
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new Database();
        }
        return self::$instance;
    }

    // Method to get the PDO instance
    public function getConnection() {
        return $this->pdo;
    }
}
?>

