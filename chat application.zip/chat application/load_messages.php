<?php
// Start session to get user ID
session_start();

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "phpchatapp_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Database connection failed: ' . $conn->connect_error]);
    exit;
}

// Set the content type to JSON
header('Content-Type: application/json');

// Get the logged-in user ID from session
$current_user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 1;

// Get receiver ID from GET parameter
$receiver_id = isset($_GET['receiver_id']) ? intval($_GET['receiver_id']) : 0;

// Validate receiver ID
if ($receiver_id <= 0) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid receiver ID.']);
    exit;
}

// Prepare SQL to fetch messages between two users
$stmt = $conn->prepare("SELECT * FROM messages 
    WHERE (sender_id = ? AND receiver_id = ?) 
    OR (sender_id = ? AND receiver_id = ?) 
    ORDER BY timestamp ASC");
$stmt->bind_param("iiii", $current_user_id, $receiver_id, $receiver_id, $current_user_id);

// Execute query
if ($stmt->execute()) {
    $result = $stmt->get_result();
    $messages = [];

    // Fetch messages
    while ($row = $result->fetch_assoc()) {
        $messages[] = $row;
    }

    // Return messages
    echo json_encode([
        'status' => 'success', 
        'messages' => $messages
    ]);
} else {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Failed to retrieve messages: ' . $stmt->error]);
}

// Close statement and connection
$stmt->close();
$conn->close();