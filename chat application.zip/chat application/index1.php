<?php

header("Content-Security-Policy: default-src 'self'; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; script-src 'self' 'unsafe-inline'; img-src 'self'; connect-src 'self'");


// Database Connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "phpchatapp_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

session_start();

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id']; // Logged-in user's ID

// Fetch user's current balance
$balance_query = $conn->prepare("SELECT balance FROM users WHERE user_id = ?");
$balance_query->bind_param("i", $user_id);
$balance_query->execute();
$balance_result = $balance_query->get_result();
$current_balance = $balance_result->fetch_assoc()['balance'];

// Fetch messages for the selected user
$receiver_id = isset($_GET['receiver_id']) ? $_GET['receiver_id'] : null;
$messages = [];
if ($receiver_id) {
    $msg_query = "SELECT * FROM messages WHERE 
        (sender_id = ? AND receiver_id = ?) OR 
        (sender_id = ? AND receiver_id = ?) 
        ORDER BY timestamp ASC";
    $stmt = $conn->prepare($msg_query);
    if ($stmt === false) {
        die("Error preparing message query: " . $conn->error);
    }
    $stmt->bind_param("iiii", $user_id, $receiver_id, $receiver_id, $user_id);
    $stmt->execute();
    $messages_result = $stmt->get_result();
    while ($row = $messages_result->fetch_assoc()) {
        $messages[] = $row;
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat - Junior & Senior</title>
    <link rel="stylesheet" href="bootstrap-icons-1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="index1.css">
</head>
<body>
    <div class="sidebar">
        <div class="logo-details">
            <i class='bx bxl-c-plus-plus icon'></i>
            <div class="logo_name">PeerCollab</div>
            <i class="bi bi-list" id="btn"></i>
        </div>
        <ul class="nav-list">
            <li>
                <a href="index1.php">
                    <i class="bi bi-chat-dots-fill"></i>
                    <span class="links_name">Chat</span>
                </a>
                <span class="tooltip">Chat</span>
            </li>
            <li>
                <a href="booking.php">
                    <i class="bi bi-calendar-check-fill"></i>
                    <span class="links_name">My booking</span>
                </a>
                <span class="tooltip">My booking</span>
            </li>
            <li>
                <a href="topup.php">
                    <i class="bi bi-bank"></i>
                    <span class="links_name">Top up money</span>
                </a>
                <span class="tooltip">Top up money</span>
            </li>
            <li>
                <a href="setting.php">
                    <i class="bi bi-gear"></i>
                    <span class="links_name">Setting</span>
                </a>
                <span class="tooltip">Setting</span>
            </li>
            <li class="profile">
                <div class="profile-details">
                    <img src="images/handsome_guy.jpg" alt="profileImg">
                    <div class="name_job">
                        <div class="name">David</div>
                    </div>
                </div>
                <a href="homepage.html">
                    <i class='bi bi-box-arrow-left' id="log_out"></i>
                </a>
            </li>
        </ul>
    </div>

    <section class="home-section">
        <div class="container-fluid">
            <div class="row">
                <!-- Chat Sidebar -->
                <div class="chat-sidebar-container">
                    <div class="chat-sidebar">
                        <div class="chat-sidebar-header">
                            <h3>Messages</h3>
                        </div>
                        <div class="users-list">
                            <?php
                            // Fetch all users except the logged-in user
                            $user_query = "SELECT user_id, name, status, role FROM users WHERE user_id != ?";
                            $stmt = $conn->prepare($user_query);
                            if ($stmt === false) {
                                die("Error preparing user query: " . $conn->error);
                            }
                            $stmt->bind_param("i", $user_id);
                            $stmt->execute();
                            $user_result = $stmt->get_result();

                            while ($user = $user_result->fetch_assoc()) {
                                ?>
                                <div class="chat-user <?php echo ($receiver_id == $user['user_id']) ? 'active' : ''; ?>">
                                    <a href="index1.php?receiver_id=<?php echo $user['user_id']; ?>">
                                        <div class="user-avatar">
                                            <img src="images/avatar.jpg" alt="avatar" style="width: 40px; height: 40px; border-radius: 50%;">
                                        </div>
                                        <div class="user-info">
                                            <h4 class="user-name"><?php echo htmlspecialchars($user['name']); ?></h4>
                                            <span class="user-role"><?php echo ucfirst($user['role']); ?></span>
                                        </div>
                                    </a>
                                </div>
                                <?php
                            }
                            ?>
                        </div>
                    </div>
                </div>

                <!-- Main Chat Area -->
                <div class="chat-main">
                    <!-- Balance Display -->
                    <div class="balance-display">
                        <div class="balance-label">Current Balance:</div>
                        <div class="balance-amount">$<?php echo number_format($current_balance, 2); ?></div>
                    </div>

                    <!-- Chat Container -->
                    <div class="chat-container" id="messages">
                        <?php if ($receiver_id): ?>
                            <?php foreach ($messages as $message): ?>
                                <div class="message <?= $message['sender_id'] == $user_id ? 'sent-message' : 'received-message' ?>">
                                    <div class="message-bubble">
                                        <?= htmlspecialchars($message['message']) ?>
                                    </div>
                                    <div class="message-time">
                                        <?= date('g:i A', strtotime($message['timestamp'])) ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center text-muted mt-5">
                                <h5>Welcome to Chat</h5>
                                <p>Select a user to start chatting</p>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <?php if ($receiver_id): ?>
                        <div class="input-buttons-container">
                            <input type="hidden" id="receiver-id" value="<?= $receiver_id ?>">
                            <input type="text" id="chat-input" class="form-control" placeholder="Type your message..." required>
                            <button id="bookingBtn" class="booking-btn">
                                <i class="bi bi-calendar-check"></i>
                                Book Session
                            </button>
                            <button type="button" id="send-btn" class="btn">
                                <i class="bi bi-send"></i>
                                Send
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <!-- Booking Modal -->
    <div id="bookingModal" class="booking-modal">
        <div class="booking-modal-content">
            <div class="booking-modal-header">
                <h2>Book a Session</h2>
                <span class="close-modal">&times;</span>
            </div>
            <div class="booking-modal-body">
                <form id="bookingForm">
                    <div class="form-group">
                        <label for="bookingAmount">Amount (USD)</label>
                        <input type="number" id="bookingAmount" min="0" step="0.01" required>
                    </div>
                    <div class="form-group">
                        <label for="bookingUser">Select User</label>
                        <select id="bookingUser" required>
                            <option value="">Select a user</option>
                            <?php
                            $stmt = $conn->prepare("SELECT user_id, name, role FROM users WHERE role = 'senior' AND user_id != ?");
                            $stmt->bind_param("i", $_SESSION['user_id']);
                            $stmt->execute();
                            $result = $stmt->get_result();
                            
                            while ($user = $result->fetch_assoc()) {
                                echo "<option value='" . $user['user_id'] . "'>" . htmlspecialchars($user['name']) . " (" . $user['role'] . ")</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="meetingDate">Meeting Date</label>
                        <input type="date" id="meetingDate" required min="<?php echo date('Y-m-d'); ?>">
                    </div>
                    <div class="form-group">
                        <label for="meetingTime">Meeting Time</label>
                        <input type="time" id="meetingTime" required>
                    </div>
                    
                    <div id="bookingError" class="error-message"></div>
                    <div class="booking-modal-footer">
                        <button type="button" class="cancel-btn">Cancel</button>
                        <button type="submit" class="confirm-btn">Confirm Booking</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="index1.js"></script>
</body>
</html>

<?php
$conn->close();
?>