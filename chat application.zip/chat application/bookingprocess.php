<?php
// bookingprocess.php
session_start();
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "phpchatapp_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Connection failed']);
    exit();
}

// Get JSON POST data
$json = file_get_contents('php://input');
$data = json_decode($json, true);

if (!$data) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request data']);
    exit();
}

$booker_id = $_SESSION['user_id'];
$booked_id = $data['booked_id'];
$amount = $data['amount'];
$meeting_datetime = $data['meeting_datetime'];

// Start transaction
$conn->begin_transaction();

try {
    // Check if booker has sufficient balance
    $balance_query = $conn->prepare("SELECT balance FROM users WHERE user_id = ?");
    $balance_query->bind_param("i", $booker_id);
    $balance_query->execute();
    $result = $balance_query->get_result();
    $current_balance = $result->fetch_assoc()['balance'];

    if ($current_balance < $amount) {
        throw new Exception("Insufficient balance");
    }

    // Deduct amount from booker
    $update_booker = $conn->prepare("UPDATE users SET balance = balance - ? WHERE user_id = ?");
    $update_booker->bind_param("di", $amount, $booker_id);
    $update_booker->execute();

    // Create booking record
    $create_booking = $conn->prepare("INSERT INTO bookings (booker_id, booked_id, amount, meeting_datetime, status) VALUES (?, ?, ?, ?, 'pending')");
    $create_booking->bind_param("iids", $booker_id, $booked_id, $amount, $meeting_datetime);
    $create_booking->execute();

    // Commit transaction
    $conn->commit();
    
    echo json_encode(['status' => 'success', 'message' => 'Booking created successfully']);
} catch (Exception $e) {
    // Rollback transaction on error
    $conn->rollback();
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}

$conn->close();
?>