<?php
/*Purpose: This file is used to register a new user. It takes the user's name, email, and password as input and stores them in the database.*/
require_once 'Database.php';

// Initialize message variables
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['mail']);
    $password = trim($_POST['pwd']);
    $passwordRepeat = trim($_POST['pwd-repeat']);

    // Validate passwords match
    if ($password !== $passwordRepeat) {
        $message = "Passwords do not match!";
        $messageType = "error";
    } 
    // Validate empty fields
    elseif (empty($name) || empty($email) || empty($password)) {
        $message = "All fields are required!";
        $messageType = "error";
    }
    else {
        try {
            // Get the singleton instance of the database
            $db = Database::getInstance();
            $pdo = $db->getConnection();

            // Hash password after validation
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            $stmt = $pdo->prepare("INSERT INTO users (name, email, password) VALUES (:name, :email, :password)");
            $stmt->bindParam(':name', $name, PDO::PARAM_STR);
            $stmt->bindParam(':email', $email, PDO::PARAM_STR);
            $stmt->bindParam(':password', $hashedPassword, PDO::PARAM_STR);

            if ($stmt->execute()) {
                $message = "Registration successful! You can now log in.";
                $messageType = "success";
            } else {
                $message = "Error occurred during registration.";
                $messageType = "error";
            }
        } catch (PDOException $e) {
            $message = "Error: " . $e->getMessage();
            $messageType = "error";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .signup-container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
        }
        .signup-container h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #333;
            font-size: 24px;
        }
        .signup-container form {
            display: flex;
            flex-direction: column;
        }
        .form-group {
            margin-bottom: 20px;
            position: relative;
        }
        .form-group label {
            font-size: 14px;
            color: #555;
            margin-bottom: 8px;
            display: block;
        }
        .form-group input {
            width: 100%;
            padding: 12px;
            border: 2px solid #e1e1e1;
            border-radius: 6px;
            font-size: 16px;
            box-sizing: border-box;
            transition: all 0.3s ease;
        }
        .form-group input:focus {
            border-color: #007bff;
            box-shadow: 0 0 0 3px rgba(0,123,255,0.1);
            outline: none;
        }
        .signup-button {
            background-color: #007bff;
            color: white;
            padding: 14px;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            font-weight: bold;
        }
        .signup-button:hover {
            background-color: #0056b3;
        }
        .message {
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            text-align: center;
            animation: fadeIn 0.5s ease-in;
        }
        .message.success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .message.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .login-link {
            text-align: center;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }
        .login-link span {
            color: #666;
        }
        .login-link a {
            color: #007bff;
            text-decoration: none;
            font-weight: bold;
        }
        .login-link a:hover {
            text-decoration: underline;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <div class="signup-container">
        <h2>Sign Up</h2>

        <?php if (!empty($message)): ?>
            <div class="message <?php echo $messageType; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <form action="signup.php" method="POST">
            <div class="form-group">
                <label for="name">Username</label>
                <input type="text" id="name" name="name" placeholder="Enter your username" required>
            </div>
            <div class="form-group">
                <label for="mail">Email</label>
                <input type="email" id="mail" name="mail" placeholder="Enter your email" required>
            </div>
            <div class="form-group">
                <label for="pwd">Password</label>
                <input type="password" id="pwd" name="pwd" placeholder="Enter your password" required>
            </div>
            <div class="form-group">
                <label for="pwd-repeat">Confirm Password</label>
                <input type="password" id="pwd-repeat" name="pwd-repeat" placeholder="Confirm your password" required>
            </div>
            <button type="submit" class="signup-button">Sign Up</button>
        </form>

        <div class="login-link">
            <span>Already have an account?</span>
            <a href="login.php">Log in</a>
        </div>
    </div>
</body>
</html>