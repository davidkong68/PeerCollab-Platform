document.addEventListener('DOMContentLoaded', function() {
    // Initialize selected subjects array
    window.selectedSubjects = [];

    // Function to toggle subject selection
    window.toggleSubject = function(element, subject) {
        element.classList.toggle('selected');
        
        const index = selectedSubjects.indexOf(subject);
        if (index === -1) {
            // Add subject if not already selected
            selectedSubjects.push(subject);
        } else {
            // Remove subject if already selected
            selectedSubjects.splice(index, 1);
        }
        
        // Update the hidden input with the selected subjects
        document.getElementById('selected_courses').value = JSON.stringify(selectedSubjects);
        
        // Console log for debugging
        console.log('Selected subjects:', selectedSubjects);
        console.log('Hidden input value:', document.getElementById('selected_courses').value);
    };

    // Function to handle role selection
    window.selectRole = function(role) {
        // Remove selected class from all role options
        document.querySelectorAll('.role-option').forEach(option => {
            option.classList.remove('selected');
        });

        // Add selected class to chosen role and check its radio button
        const roleElement = document.querySelector(`#${role}`);
        if (roleElement) {
            roleElement.closest('.role-option').classList.add('selected');
            roleElement.checked = true;
        }

        // Console log for debugging
        console.log('Selected role:', role);
    };

    // Form submission validation
    document.querySelector('form').addEventListener('submit', function(e) {
        const selectedCoursesValue = document.getElementById('selected_courses').value;
        const customSubject = document.getElementById('subject').value.trim();
        const roleSelected = document.querySelector('input[name="role"]:checked');

        // Check if either courses are selected or custom subject is entered
        if ((!selectedCoursesValue || selectedCoursesValue === '[]') && !customSubject) {
            e.preventDefault();
            alert('Please select at least one subject or enter a custom subject');
            return false;
        }

        // Check if role is selected
        if (!roleSelected) {
            e.preventDefault();
            alert('Please select your role (Senior or Junior)');
            return false;
        }

        // Console log form data before submission
        console.log('Form submission data:', {
            selectedCourses: selectedCoursesValue,
            customSubject: customSubject,
            role: roleSelected.value
        });
    });

    // Initialize role selection on page load
    selectRole('senior');
});