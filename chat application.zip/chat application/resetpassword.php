<?php
require_once 'Database.php';

session_start();
$message = '';
$token = isset($_GET['token']) ? $_GET['token'] : '';

// Check if email is in session
if (!isset($_SESSION['reset_email'])) {
    header("Location: forgotpassword.php");
    exit;
}

$email = $_SESSION['reset_email'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_password = trim($_POST['new_password']);
    $confirm_password = trim($_POST['confirm_password']);
    $token = trim($_POST['token']);

    if ($new_password !== $confirm_password) {
        $message = "Passwords do not match.";
    } elseif (strlen($new_password) < 1) {
        $message = "Password must be at least 1 characters long.";
    } else {
        try {
            $db = Database::getInstance();
            $pdo = $db->getConnection();

            // Verify token
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email AND reset_token = :token");
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':token', $token);
            $stmt->execute();

            if ($stmt->rowCount() > 0) {
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                
                // Update password and clear token
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $updateStmt = $pdo->prepare("UPDATE users SET password = :password, reset_token = NULL WHERE user_id = :user_id");
                $updateStmt->bindParam(':password', $hashed_password);
                $updateStmt->bindParam(':user_id', $user['user_id']);
                
                if ($updateStmt->execute()) {
                    // Clear the reset email from session
                    unset($_SESSION['reset_email']);
                    $message = "Password successfully updated. Redirecting to login page...";
                    header("refresh:3;url=login.php");
                } else {
                    $message = "Failed to update password.";
                }
            } else {
                $message = "Invalid reset token or email.";
            }
        } catch (PDOException $e) {
            $message = "Error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .reset-container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            font-size: 14px;
            color: #555;
            position: relative;
            bottom: 5px;
        }
        .form-group input {
            width: 95%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }
        .submit-button {
            background-color: #007bff;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            width: 100%;
        }
        .submit-button:hover {
            background-color: #0056b3;
        }
        .message {
            color: #28a745;
            text-align: center;
            margin-bottom: 15px;
        }
        .message.error {
            color: #dc3545;
        }
    </style>
</head>
<body>
    <div class="reset-container">
        <h2>Reset Password</h2>
        <?php if ($message): ?>
            <div class="message <?php echo strpos($message, 'successfully') ? '' : 'error'; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>
        <form action="resetpassword.php" method="POST">
            <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
            <div class="form-group">
                <label for="new_password">New Password</label>
                <input type="password" id="new_password" name="new_password" placeholder="Enter new password" required>
            </div>
            <div class="form-group">
                <label for="confirm_password">Confirm New Password</label>
                <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm new password" required>
            </div>
            <button type="submit" class="submit-button">Set New Password</button>
        </form>
    </div>
</body>
</html>