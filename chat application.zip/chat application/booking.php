<?php
// Database Connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "phpchatapp_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

session_start();

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch bookings where user is either the booker or the booked person
$booking_query = "
    SELECT 
        b.*,
        u1.name as booker_name,
        u2.name as booked_name
    FROM bookings b
    JOIN users u1 ON b.booker_id = u1.user_id
    JOIN users u2 ON b.booked_id = u2.user_id
    WHERE b.booker_id = ? OR b.booked_id = ?
    ORDER BY b.created_at DESC
";

$stmt = $conn->prepare($booking_query);
$stmt->bind_param("ii", $user_id, $user_id);
$stmt->execute();
$bookings_result = $stmt->get_result();

// Count pending bookings
$pending_count = 0;
$bookings = [];
while ($booking = $bookings_result->fetch_assoc()) {
    $bookings[] = $booking;
    if ($booking['status'] === 'pending' && $booking['booked_id'] === $user_id) {
        $pending_count++;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Bookings - Junior & Senior</title>
    <meta http-equiv="Content-Security-Policy" content="default-src 'self'; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; script-src 'self' 'unsafe-inline'; img-src 'self';">
    <link rel="stylesheet" href="bootstrap-icons-1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="booking.css">
    

</head>
<body>
    <div class="sidebar">
        <div class="logo-details">
            <i class='bx bxl-c-plus-plus icon'></i>
            <div class="logo_name">PeerCollab</div>
            <i class="bi bi-list" id="btn"></i>
        </div>
        <ul class="nav-list">
            <li>
                <a href="index1.php">
                    <i class="bi bi-chat-dots-fill"></i>
                    <span class="links_name">Chat</span>
                </a>
                <span class="tooltip">Chat</span>
            </li>
            <li>
                <a href="booking.php" class="active">
                    <i class="bi bi-calendar-check-fill"></i>
                    <span class="links_name">My booking</span>
                
                </a>
                <span class="tooltip">My booking</span>
            </li>
            <li>
                <a href="topup.php">
                    <i class="bi bi-bank"></i>
                    <span class="links_name">Top up money</span>
                </a>
                <span class="tooltip">Top up money</span>
            </li>
            <li>
                <a href="setting.php">
                    <i class="bi bi-gear"></i>
                    <span class="links_name">Setting</span>
                </a>
                <span class="tooltip">Setting</span>
            </li>
            <li class="profile">
                <div class="profile-details">
                    <img src="images/handsome_guy.jpg" alt="profileImg">
                    <div class="name_job">
                        <div class="name">David</div>
                    </div>
                </div>
                <a href="homepage.html">
                    <i class='bi bi-box-arrow-left' id="log_out"></i>
                </a>
            </li>
        </ul>
    </div>

    <section class="home-section">
        <div class="text">My Bookings</div>

        <div class="booking-container">
            <div class="booking-header">
                <div class="booking-filters">
                    <button class="filter-btn active" data-filter="all">All</button>
                    <button class="filter-btn" data-filter="pending">Pending</button>
                    <button class="filter-btn" data-filter="confirmed">Confirmed</button>
                </div>
            </div>

            <div class="booking-list">
    <?php if (empty($bookings)): ?>
        <div class="no-bookings">
            <i class="bi bi-calendar-x" style="font-size: 2em; margin-bottom: 10px;"></i>
            <p>No bookings found</p>
        </div>
    <?php else: ?>
        <?php foreach ($bookings as $booking): ?>
            <div class="booking-card" data-status="<?php echo $booking['status']; ?>">
                <div class="booking-details">
                  <div>
                        <div>
                            <?php if ($booking['booker_id'] === $user_id): ?>
                                You booked a session with <strong><?php echo htmlspecialchars($booking['booked_name']); ?></strong>
                            <?php else: ?>
                                <strong><?php echo htmlspecialchars($booking['booker_name']); ?></strong> booked a session with <strong><?php echo htmlspecialchars($booking['booked_name']); ?></strong>
                            <?php endif; ?>
                        </div>
                  </div>
                    <div class="booking-date">
                        <strong>Created:</strong> <?php echo date('F j, Y g:i A', strtotime($booking['created_at'])); ?>
                    </div>
                    <?php if (isset($booking['meeting_datetime'])): ?>
                        <div class="meeting-time">
                            <strong>Meeting Time:</strong> <?php echo date('F j, Y g:i A', strtotime($booking['meeting_datetime'])); ?>
                        </div>
                    <?php endif; ?>
                    <div class="booking-amount">
                        <strong>Amount:</strong> $<?php echo number_format($booking['amount'], 2); ?>
                    </div>
                </div>
                <div class="booking-status-container">
                    <div class="booking-status status-<?php echo $booking['status']; ?>">
                        <?php echo ucfirst($booking['status']); ?>
                    </div>
                    
                    <!-- Debug information -->
                    <div class="debug-info" style="font-size: 0.8em; color: #666; margin: 5px 0;">
                        Status: <?php echo $booking['status']; ?><br>
                        Booked ID: <?php echo $booking['booked_id']; ?><br>
                        User ID: <?php echo $user_id; ?><br>
                        Should Show Buttons: <?php echo ($booking['status'] === 'pending' && $booking['booked_id'] === $user_id) ? 'Yes' : 'No'; ?>
                    </div>
                    
                    <?php if ($booking['status'] === 'pending' && intval($booking['booked_id']) === intval($user_id)): ?>
                        <div class="booking-actions">
                            <button class="action-btn accept-btn" onclick="updateBookingStatus(<?php echo $booking['booking_id']; ?>, 'confirmed')">
                                <i class="bi bi-check-circle"></i> Accept
                            </button>
                            <button class="action-btn decline-btn" onclick="updateBookingStatus(<?php echo $booking['booking_id']; ?>, 'cancelled')">
                                <i class="bi bi-x-circle"></i> Decline
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
</div>
    </section>

    <script>
        // Booking filter functionality
        document.querySelectorAll('.filter-btn').forEach(button => {
            button.addEventListener('click', () => {
                // Remove active class from all buttons
                document.querySelectorAll('.filter-btn').forEach(btn => btn.classList.remove('active'));
                // Add active class to clicked button
                button.classList.add('active');
                
                const filter = button.dataset.filter;
                document.querySelectorAll('.booking-card').forEach(card => {
                    if (filter === 'all' || card.dataset.status === filter) {
                        card.style.display = 'flex';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });

        function updateBookingStatus(bookingId, status) {
            if (!confirm(`Are you sure you want to ${status} this booking?`)) {
                return;
            }

            fetch('updatebooking.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    booking_id: bookingId,
                    status: status
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    location.reload();
                } else {
                    alert('Failed to update booking status: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while updating the booking status');
            });
        }
    </script>

    <script src="booking.js"></script>
</body>
</html>

<?php $conn->close(); ?>

