<?php
session_start();
header('Content-Type: application/json');

// Enable error reporting and logging
error_reporting(E_ALL);
ini_set('display_errors', 1);

function debug_log($message) {
    error_log("Add Course Debug: " . print_r($message, true));
}

// Check for login
if (!isset($_SESSION['user_id'])) {
    debug_log("No user_id in session");
    echo json_encode(['status' => 'error', 'message' => 'Not logged in']);
    exit;
}

debug_log("User ID from session: " . $_SESSION['user_id']);

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "phpchatapp_db";

try {
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }
    
    debug_log("Database connected successfully");

    // Get and parse input data
    $input = file_get_contents('php://input');
    debug_log("Raw input: " . $input);
    
    $data = json_decode($input, true);
    debug_log("Decoded data: " . print_r($data, true));

    if (!isset($data['course_name'])) {
        throw new Exception("Course name is missing from input");
    }

    $userId = $_SESSION['user_id'];
    $courseName = trim($data['course_name']);

    // Validate course name
    if (empty($courseName)) {
        throw new Exception("Course name cannot be empty");
    }
    
    // Add length validation
    if (strlen($courseName) > 255) {
        throw new Exception("Course name is too long (maximum 255 characters)");
    }

    debug_log("Processing - User ID: $userId, Course Name: $courseName");

    // Check if course already exists for this user
    $stmt = $conn->prepare("SELECT id FROM course WHERE user_id = ? AND course_name = ?");
    if (!$stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    
    $stmt->bind_param("is", $userId, $courseName);
    if (!$stmt->execute()) {
        throw new Exception("Check query failed: " . $stmt->error);
    }
    
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        throw new Exception("You have already added this course");
    }
    $stmt->close();

    // Verify user exists
    $userCheck = $conn->prepare("SELECT user_id FROM users WHERE user_id = ?");
    $userCheck->bind_param("i", $userId);
    $userCheck->execute();
    if ($userCheck->get_result()->num_rows === 0) {
        throw new Exception("Invalid user ID");
    }
    $userCheck->close();

    // Insert the new course
    $stmt = $conn->prepare("INSERT INTO course (user_id, course_name) VALUES (?, ?)");
    if (!$stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("is", $userId, $courseName);
    
    if (!$stmt->execute()) {
        throw new Exception("Failed to insert course: " . $stmt->error);
    }
    
    $newCourseId = $stmt->insert_id;
    debug_log("Course inserted successfully with ID: " . $newCourseId);
    
    // Verify the insertion
    $verifyStmt = $conn->prepare("SELECT id, course_name FROM course WHERE id = ?");
    $verifyStmt->bind_param("i", $newCourseId);
    $verifyStmt->execute();
    $verifyResult = $verifyStmt->get_result();
    $insertedCourse = $verifyResult->fetch_assoc();
    
    echo json_encode([
        'status' => 'success',
        'message' => 'Course added successfully',
        'course_id' => $newCourseId,
        'course_name' => $insertedCourse['course_name']
    ]);

} catch (Exception $e) {
    debug_log("Error occurred: " . $e->getMessage());
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
} finally {
    if (isset($stmt)) {
        $stmt->close();
    }
    if (isset($verifyStmt)) {
        $verifyStmt->close();
    }
    if (isset($conn)) {
        $conn->close();
    }
}
?>