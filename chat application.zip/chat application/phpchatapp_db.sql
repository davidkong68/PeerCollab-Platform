-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 03, 2025 at 02:19 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `phpchatapp_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `booking_id` int(11) NOT NULL,
  `booker_id` int(11) NOT NULL COMMENT 'User who made the booking',
  `booked_id` int(11) NOT NULL COMMENT 'User who was booked',
  `amount` decimal(10,2) NOT NULL,
  `status` enum('pending','confirmed','cancelled') NOT NULL DEFAULT 'pending',
  `booking_date` datetime NOT NULL,
  `meeting_datetime` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`booking_id`, `booker_id`, `booked_id`, `amount`, `status`, `booking_date`, `meeting_datetime`, `created_at`, `updated_at`) VALUES
(17, 1, 2, 32.00, 'pending', '2024-12-11 16:07:43', NULL, '2024-12-11 08:07:43', '2024-12-11 08:07:43'),
(18, 1, 2, 2.00, 'confirmed', '0000-00-00 00:00:00', '2025-07-16 11:37:00', '2025-07-03 10:33:36', '2025-07-03 12:15:45');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `course_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `user_id`, `course_name`) VALUES
(5, 1, 'Computer Science'),
(6, 1, 'Mathematics'),
(13, 8, 'Biology'),
(14, 8, 'Entreprenuer'),
(15, 1, 'Biology'),
(16, 1, 'English'),
(17, 2, 'Computer Science'),
(18, 2, 'Coding'),
(19, 2, 'Test Course'),
(21, 1, 'Test Course'),
(23, 9, 'English'),
(24, 9, 'Cantonese'),
(25, 9, 'Test Course');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `sender_id`, `receiver_id`, `message`, `timestamp`) VALUES
(1, 8, 2, 'hi', '2024-11-27 09:38:15'),
(2, 8, 2, 'nice to meet you', '2024-11-27 09:39:34'),
(3, 8, 2, 'bye', '2024-11-27 09:44:02'),
(4, 8, 2, 'success', '2024-11-27 09:44:19'),
(5, 8, 2, 'success', '2024-11-27 09:44:26'),
(6, 8, 2, 'sdfdsfsd', '2024-11-27 09:55:08'),
(7, 8, 2, 'Good', '2024-11-28 02:00:43'),
(8, 8, 2, 'sdfsdf', '2024-11-28 02:59:41'),
(9, 8, 2, 'Good morning', '2024-11-28 02:59:54'),
(10, 8, 2, 'dfsf', '2024-11-28 03:00:58'),
(11, 8, 2, 'hi', '2024-11-28 03:44:26'),
(12, 8, 2, 'well', '2024-11-28 03:51:58'),
(13, 8, 2, 'hu', '2024-12-01 07:00:28'),
(14, 8, 2, 'fdsf', '2024-12-01 08:30:53'),
(15, 8, 2, 'd', '2024-12-01 08:36:36'),
(16, 1, 2, 'fdf', '2024-12-01 13:18:40'),
(17, 1, 2, 'f', '2024-12-01 13:19:09'),
(18, 1, 2, 'I am back', '2024-12-01 13:19:27'),
(19, 1, 2, 'working', '2024-12-01 13:28:21'),
(20, 1, 2, 'hi', '2025-07-03 10:00:25'),
(21, 2, 1, 'Good afternoon', '2025-07-03 10:01:40'),
(22, 1, 2, 'How are you?', '2025-07-03 12:15:17'),
(23, 1, 9, 'hi', '2025-07-03 12:18:41');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `transaction_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `type` enum('deposit','withdrawal','payment') NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `reference_number` varchar(100) NOT NULL,
  `status` enum('pending','completed','failed') NOT NULL DEFAULT 'completed',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`transaction_id`, `user_id`, `amount`, `type`, `payment_method`, `reference_number`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 50.00, 'deposit', 'credit_card', 'TOP1672345671234', 'completed', '2025-07-03 10:17:14', '2025-07-03 10:17:14'),
(2, 1, 25.00, 'deposit', 'bank_transfer', 'TOP1672345681235', 'completed', '2025-07-03 10:17:14', '2025-07-03 10:17:14'),
(3, 2, 100.00, 'deposit', 'e_wallet', 'TOP1672345691236', 'completed', '2025-07-03 10:17:14', '2025-07-03 10:17:14'),
(4, 1, 5.00, 'deposit', 'credit_card', 'TOP17515378486174', 'completed', '2025-07-03 10:17:28', '2025-07-03 10:17:28'),
(5, 1, 10.00, 'deposit', 'credit_card', 'TOP17515378549354', 'completed', '2025-07-03 10:17:34', '2025-07-03 10:17:34'),
(6, 2, 12.00, 'deposit', 'credit_card', 'TOP17515379656656', 'completed', '2025-07-03 10:19:25', '2025-07-03 10:19:25'),
(7, 2, 50.00, 'deposit', 'bank_transfer', 'TOP17515382351952', 'completed', '2025-07-03 10:23:55', '2025-07-03 10:23:55'),
(8, 2, 2.00, 'deposit', 'bank_transfer', 'TOP17515384387312', 'completed', '2025-07-03 10:27:18', '2025-07-03 10:27:18'),
(9, 2, 3.00, 'deposit', 'bank_transfer', 'TOP17515384424771', 'completed', '2025-07-03 10:27:22', '2025-07-03 10:27:22'),
(10, 2, 1.00, 'deposit', 'e_wallet', 'TOP17515449523884', 'completed', '2025-07-03 12:15:52', '2025-07-03 12:15:52');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `unique_id` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL COMMENT 'Offline now, Online',
  `course` text DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `role` enum('senior','junior') NOT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `balance` decimal(10,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `unique_id`, `email`, `password`, `reset_token`, `status`, `course`, `subject`, `role`, `profile_image`, `balance`, `created_at`, `updated_at`) VALUES
(1, 'david', '67435338c9c45', 'davidkong6868@gmail.com', '$2y$10$xKRU27Eau.V7BedwuSQ6deyynqnv6nlNM2Rhhn7.Z.cW9zX6zY6Zq', NULL, 'Offline', NULL, NULL, 'senior', '68665a70189eb_handsome_guy.jpg', 13.00, '2024-11-27 02:22:56', '2025-07-03 12:14:51'),
(2, 'Joshua', '674358e817aec', 'joshua4794@gmail.com', '$2y$10$A2YJmv8np.hIn4UNMg29fuaRVEtkHyvdt7MqC2LT2nVMX36Z1UMeq', NULL, 'Offline', NULL, NULL, 'senior', '686674b5efbc0_handsome_guy.jpg', 70.00, '2024-11-27 02:22:56', '2025-07-03 12:16:53'),
(3, 'test', NULL, 'test123@gmail.com', '$2y$10$PE7VqWzoiVSqxd2ILG3Hbe2NLm5ANpxPaRKzgAs7fOkoC5.wW0rqa', NULL, NULL, NULL, NULL, 'senior', NULL, 0.00, '2024-11-27 02:22:56', '2024-11-27 02:22:56'),
(4, '123', NULL, '123@gmail.com', '$2y$10$aPa0PIB4hXWwZj1oqsyR5Ov11PS3svYcKBIilJIPvqlJET9bt2Hra', NULL, NULL, NULL, NULL, 'senior', NULL, 0.00, '2024-11-27 02:22:56', '2024-11-27 02:22:56'),
(5, '567', NULL, '567@gmail.com', '$2y$10$Mhl4GnYWGUQinIEIsE708eI9KerLa5jPc0OdC65w2TwHmiLx03xg6', NULL, NULL, NULL, NULL, 'senior', NULL, 0.00, '2024-11-27 02:22:56', '2024-11-27 02:22:56'),
(6, '345', NULL, '345@gmail.com', '$2y$10$VJctNSv7I7ehwwE4uKwmAeU2ceA3ICJpIWNd9W6SGBQAwm8.1NhAi', NULL, NULL, NULL, NULL, 'senior', NULL, 0.00, '2024-11-27 02:24:19', '2024-11-27 02:24:19'),
(7, '888', NULL, '888@gmail.com', '$2y$10$7IV09cl1gEr9Yna1fSzffOlVO392cAKMe5Ll/B9/E8pLP0hjT9eay', NULL, NULL, NULL, NULL, 'senior', NULL, 0.00, '2024-11-27 02:24:59', '2024-11-27 02:24:59'),
(8, 'data', NULL, 'data@gmail.com', '$2y$10$bCaGtEnXI3ftb81q50hnNObOwsyOIsWHoj5In99Yy1rKi//5qj5QS', NULL, NULL, NULL, NULL, 'junior', NULL, 0.00, '2024-11-27 08:44:21', '2024-11-27 08:45:08'),
(9, 'Peter', NULL, 'peter@gmail.com', '$2y$10$b5iNdoThmlxKHqClPwPmH.an3g30cSeybdXPySTj0BbqIHcOStgue', NULL, NULL, NULL, NULL, 'senior', NULL, 0.00, '2025-07-03 12:17:50', '2025-07-03 12:17:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`booking_id`),
  ADD KEY `booker_id` (`booker_id`),
  ADD KEY `booked_id` (`booked_id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`transaction_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `course`
--
ALTER TABLE `course`
  ADD CONSTRAINT `course_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
