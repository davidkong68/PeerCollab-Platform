document.addEventListener('DOMContentLoaded', function () {
    // Chat elements
    const userListDiv = document.querySelector('.user-list');
    const receiverIdInput = document.getElementById('receiver-id');
    const chatInput = document.getElementById('chat-input');
    const sendBtn = document.getElementById('send-btn');
    const chatContainer = document.querySelector('.chat-container');

    // Check if we're on the chat page
    if (chatInput && sendBtn) {
        // Function to create a message element
        function createMessageElement(message) {
            const messageWrapper = document.createElement('div');
            messageWrapper.className = `message ${message.sender_id === 1 ? 'sent-message' : 'received-message'}`;
            
            const messageBubble = document.createElement('div');
            messageBubble.className = 'message-bubble';
            messageBubble.textContent = message.message;
            
            const messageTime = document.createElement('div');
            messageTime.className = 'message-time';
            messageTime.textContent = new Date(message.timestamp).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
            
            messageWrapper.appendChild(messageBubble);
            messageWrapper.appendChild(messageTime);
            
            return messageWrapper;
        }

        // Function to load messages
        function loadMessages(receiverId) {
            fetch(`load_messages.php?receiver_id=${receiverId}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.status === 'success') {
                        chatContainer.innerHTML = '';
                        data.messages.forEach(message => {
                            const messageElement = createMessageElement(message);
                            chatContainer.appendChild(messageElement);
                        });
                        chatContainer.scrollTop = chatContainer.scrollHeight;
                    } else {
                        console.error('Error loading messages:', data.message);
                        alert('Failed to load messages: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Fetch error:', error);
                    alert('Error loading messages: ' + error.message);
                });
        }

        // Send message event listener
        sendBtn.addEventListener('click', function () {
            const message = chatInput.value.trim();
            const receiverId = receiverIdInput.value.trim();

            if (!message || !receiverId) {
                alert("Please type a message and select a user!");
                return;
            }

            const formData = new FormData();
            formData.append('message', message);
            formData.append('receiver_id', receiverId);

            fetch('send_message.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    return response.json().then(errorData => {
                        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
                    });
                }
                return response.json();
            })
            .then(data => {
                if (data.status === 'success') {
                    const newMessage = {
                        message: message,
                        sender_id: 1,
                        timestamp: new Date().toISOString()
                    };
                    const messageElement = createMessageElement(newMessage);
                    chatContainer.appendChild(messageElement);
                    
                    chatInput.value = '';
                    chatContainer.scrollTop = chatContainer.scrollHeight;
                } else {
                    console.error('Error sending message:', data.message);
                    alert('Failed to send message: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Fetch error:', error);
                alert('Error sending message: ' + error.message);
            });
        });

        // Handle Enter key in chat input
        chatInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendBtn.click();
            }
        });

        // Event listener for user selection
        if (userListDiv) {
            userListDiv.addEventListener('click', function (event) {
                const selectedUser = event.target.closest('.chat-user');
                if (selectedUser) {
                    document.querySelectorAll('.chat-user').forEach(user => {
                        user.classList.remove('active');
                    });
                    
                    selectedUser.classList.add('active');
                    
                    const userId = selectedUser.querySelector('a').getAttribute('href').split('=')[1];
                    receiverIdInput.value = userId;
                    
                    loadMessages(userId);
                }
            });
        }
    }

    // Booking Modal functionality
    const bookingModal = document.getElementById('bookingModal');
    const bookingBtn = document.getElementById('bookingBtn');
    const closeBtn = document.querySelector('.close-modal');
    const cancelBtn = document.querySelector('.cancel-btn');
    const bookingForm = document.getElementById('bookingForm');
    const errorMessage = document.getElementById('bookingError');
    const meetingDateInput = document.getElementById('meetingDate');

    // Only initialize booking if modal exists
    if (bookingModal && bookingBtn) {
        // Set minimum date to today
        if (meetingDateInput) {
            meetingDateInput.min = new Date().toISOString().split('T')[0];
        }

        bookingBtn.addEventListener('click', function() {
            bookingModal.style.display = 'block';
        });

        function closeModal() {
            bookingModal.style.display = 'none';
            if (bookingForm) bookingForm.reset();
            if (errorMessage) {
                errorMessage.textContent = '';
                errorMessage.style.display = 'none';
            }
        }

        if (closeBtn) closeBtn.addEventListener('click', closeModal);
        if (cancelBtn) cancelBtn.addEventListener('click', closeModal);

        window.addEventListener('click', function(event) {
            if (event.target === bookingModal) closeModal();
        });

        if (bookingForm) {
            bookingForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const amount = document.getElementById('bookingAmount').value;
                const userId = document.getElementById('bookingUser').value;
                const meetingDate = document.getElementById('meetingDate').value;
                const meetingTime = document.getElementById('meetingTime').value;

                if (!amount || !userId || !meetingDate || !meetingTime) {
                    if (errorMessage) {
                        errorMessage.textContent = 'Please fill in all fields';
                        errorMessage.style.display = 'block';
                    }
                    return;
                }

                // Create form data
                const formData = new FormData();
                formData.append('booked_id', userId);
                formData.append('amount', amount);
                formData.append('meeting_datetime', `${meetingDate} ${meetingTime}`);

                // Send booking request
                fetch('bookingprocess.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.text().then(text => {
                        try {
                            return JSON.parse(text);
                        } catch (e) {
                            throw new Error('Invalid response format: ' + text);
                        }
                    });
                })
                .then(data => {
                    if (data.status === 'success') {
                        alert('Booking request sent successfully! Awaiting confirmation.');
                        closeModal();
                        location.reload();
                    } else {
                        if (errorMessage) {
                            errorMessage.textContent = data.message || 'Booking failed';
                            errorMessage.style.display = 'block';
                        }
                    }
                })
                .catch(error => {
                    console.error('Booking error:', error);
                    if (errorMessage) {
                        errorMessage.textContent = 'An error occurred while processing your booking. Please try again.';
                        errorMessage.style.display = 'block';
                    }
                });
            });
        }
    }

    // Sidebar functionality
    const sidebar = document.querySelector(".sidebar");
    const sidebarBtn = document.querySelector("#btn");

    if (sidebar && sidebarBtn) {
        sidebarBtn.addEventListener("click", () => {
            sidebar.classList.toggle("open");
            if (sidebar.classList.contains("open")) {
                sidebarBtn.classList.replace("bi-list", "bi-x-lg");
            } else {
                sidebarBtn.classList.replace("bi-x-lg", "bi-list");
            }
        });
    }
});