<?php
session_start();
$error = '';

// Process form submission first, before any output
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once 'Database.php';
    $db = Database::getInstance();
    $pdo = $db->getConnection();

    if (!isset($_POST['role'])) {
        $error = 'Please select a role (Senior or Junior)';
    } else {
        // Get selected courses from JSON and ensure it's an array
        $selectedCourses = json_decode($_POST['selected_courses'], true) ?: [];
        $customSubject = trim($_POST['subject'] ?? '');
        $role = $_POST['role'];

        // Add custom subject if provided
        if (!empty($customSubject)) {
            $selectedCourses[] = $customSubject;
        }

        // Validate that at least one course is selected
        if (empty($selectedCourses)) {
            $error = 'Please select at least one subject';
        } else {
            try {
                $pdo->beginTransaction();

                // Update user role
                $updateRole = $pdo->prepare("UPDATE users SET role = ? WHERE user_id = ?");
                $updateRole->execute([$role, $_SESSION['user_id']]);

                // First, delete any existing courses for this user
                $deleteCourses = $pdo->prepare("DELETE FROM course WHERE user_id = ?");
                $deleteCourses->execute([$_SESSION['user_id']]);

                // Insert courses using the correct column names
                $insertCourse = $pdo->prepare("INSERT INTO course (user_id, course_name) VALUES (?, ?)");
                
                foreach ($selectedCourses as $course) {
                    $insertCourse->execute([$_SESSION['user_id'], $course]);
                }

                $pdo->commit();

                // Redirect to main page after successful save
                header('Location: index1.php');
                exit;

            } catch (PDOException $e) {
                $pdo->rollBack();
                $error = "Database Error: " . $e->getMessage();
            }
        }
    }
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Check if user has already enrolled in courses
try {
    require_once 'Database.php';
    $db = Database::getInstance();
    $pdo = $db->getConnection();

    $stmt = $pdo->prepare("SELECT COUNT(*) FROM course WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $hasEnrolled = $stmt->fetchColumn() > 0;

    // If user has already enrolled, redirect to index1.php
    if ($hasEnrolled) {
        header('Location: index1.php');
        exit;
    }
} catch (PDOException $e) {
    $error = "Database Error: " . $e->getMessage();
}

// List of subjects
$courses = [
    "Computer Science",
    "English",
    "Web Programming",
    "Marketing",
    "Computer Mathematics",
    "Business",
    "Chinese",
    "Bahasa Malaysia"
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course and Role Selection</title>
    <link rel="stylesheet" href="enrollcourse.css">
</head>
<body>
    <div class="container">
        <h1>Course Enrollment</h1>
        
        <div class="welcome-message">
            Welcome, <strong><?php echo htmlspecialchars($_SESSION['user_name']); ?></strong>! 
            Select the subject you want help with..
        </div>
        
        <?php if (!empty($error)): ?>
            <div class="error-message">
                <span class="error-icon">!</span>
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label>Select Your Subjects</label>
                <div class="subject-list">
                    <?php foreach ($courses as $course): ?>
                        <div class="subject-option" onclick="toggleSubject(this, '<?php echo htmlspecialchars($course); ?>')">
                            <?php echo htmlspecialchars($course); ?>
                        </div>
                    <?php endforeach; ?>
                </div>
                <input type="hidden" name="selected_courses" id="selected_courses" value="">
            </div>

            <div class="form-group">
                <label for="subject">Add Custom Subject</label>
                <input type="text" id="subject" name="subject" 
                    class="custom-input" 
                    placeholder="Enter a subject that's not listed above">
            </div>

            <div class="form-group">
                <label>Select Your Role</label>
                <div class="role-selection">
                    <div class="role-option" onclick="selectRole('senior')">
                        <input type="radio" id="senior" name="role" value="senior" required>
                        <label for="senior">Senior Student</label>
                    </div>
                    <div class="role-option" onclick="selectRole('junior')">
                        <input type="radio" id="junior" name="role" value="junior">
                        <label for="junior">Junior Student</label>
                    </div>
                </div>
            </div>

            <button type="submit" class="submit-btn">
                Complete Enrollment
            </button>
        </form>
    </div>

    <script>
        let selectedSubjects = [];

        function toggleSubject(element, subject) {
            element.classList.toggle('selected');
            
            const index = selectedSubjects.indexOf(subject);
            if (index === -1) {
                selectedSubjects.push(subject);
            } else {
                selectedSubjects.splice(index, 1);
            }
            
            document.getElementById('selected_courses').value = JSON.stringify(selectedSubjects);
        }

        function selectRole(role) {
            document.querySelectorAll('.role-option').forEach(option => {
                option.classList.remove('selected');
            });
            document.querySelector(`#${role}`).closest('.role-option').classList.add('selected');
            document.querySelector(`#${role}`).checked = true;
        }

        window.onload = function() {
            selectRole('senior');
        }
    </script>
</body>
</html>