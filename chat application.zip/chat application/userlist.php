<?php
// First, get the logged-in user's courses
$user_courses_query = "SELECT course_name FROM course WHERE user_id = ?";
$stmt = $conn->prepare($user_courses_query);

if (!$stmt) {
    // Handle preparation error
    die("Error preparing user courses query: " . $conn->error);
}

$stmt->bind_param("i", $user_id);
$stmt->execute();
$user_courses_result = $stmt->get_result();

$user_courses = array();
while ($course = $user_courses_result->fetch_assoc()) {
    $user_courses[] = $course['course_name'];
}

// If the user has courses, fetch users who share at least one course
if (!empty($user_courses)) {
    // Create the placeholders for the IN clause
    $placeholders = str_repeat('?,', count($user_courses) - 1) . '?';
    
    // Build the query
    $query = "
        SELECT DISTINCT u.user_id, u.name, u.role 
        FROM users u 
        INNER JOIN course c ON u.user_id = c.user_id 
        WHERE c.course_name IN ($placeholders) 
        AND u.user_id != ?
        ORDER BY u.name
    ";
    
    $stmt = $conn->prepare($query);
    
    if (!$stmt) {
        // Handle preparation error
        die("Error preparing users query: " . $conn->error);
    }
    
    // Create the types string for bind_param
    $types = str_repeat('s', count($user_courses)) . 'i';
    
    // Create array of parameters
    $params = array_merge($user_courses, [$user_id]);
    
    // Create array of references for bind_param
    $refs = array();
    $refs[] = $types;
    foreach ($params as $key => $value) {
        $refs[] = &$params[$key];
    }
    
    // Bind parameters using references
    call_user_func_array(array($stmt, 'bind_param'), $refs);
    
    if (!$stmt->execute()) {
        // Handle execution error
        die("Error executing query: " . $stmt->error);
    }
    
    $user_result = $stmt->get_result();

    // Display the filtered users
    while ($user = $user_result->fetch_assoc()) {
        // Get this user's courses
        $courses_query = "SELECT course_name FROM course WHERE user_id = ?";
        $courses_stmt = $conn->prepare($courses_query);
        
        if (!$courses_stmt) {
            continue; // Skip this user if query fails
        }
        
        $courses_stmt->bind_param("i", $user['user_id']);
        $courses_stmt->execute();
        $courses_result = $courses_stmt->get_result();
        
        $shared_courses = array();
        while ($course = $courses_result->fetch_assoc()) {
            if (in_array($course['course_name'], $user_courses)) {
                $shared_courses[] = $course['course_name'];
            }
        }
        ?>
        <div class="chat-user <?php echo ($receiver_id == $user['user_id']) ? 'active' : ''; ?>">
            <a href="index1.php?receiver_id=<?php echo $user['user_id']; ?>">
                <div class="user-avatar">
                    <i class='bi bi-person'></i>
                </div>
                <div class="user-info">
                    <h4 class="user-name"><?php echo htmlspecialchars($user['name']); ?></h4>
                    <span class="user-role"><?php echo ucfirst($user['role']); ?></span>
                    <div class="user-courses">
                        <?php foreach ($shared_courses as $course): ?>
                            <span class="course-tag"><?php echo htmlspecialchars($course); ?></span>
                        <?php endforeach; ?>
                    </div>
                </div>
            </a>
        </div>
        <?php
        $courses_stmt->close();
    }
    $stmt->close();
} else {
    // If user has no courses, show message
    echo '<div class="no-courses-message">Please select your courses first.</div>';
}
?>